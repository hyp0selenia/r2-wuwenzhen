// Interaction test: mock storage API + the real Worker UI + a headless browser.
import { spawn } from "node:child_process";
import { createServer } from "node:http";

import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// Paths are derived from this file so the scripts work from any clone location.
const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const TMP = join(ROOT, ".tmp");
mkdirSync(TMP, { recursive: true });

// ---------------------------------------------------------------- mock upstream
const objects = [
  { key: "software/tools/app-1.0.apk", size: 2048, uploaded: "2026-09-01T10:00:00.000Z" },
  { key: "software/tools/app-1.1.apk", size: 3932160, uploaded: "2026-09-02T10:00:00.000Z" },
  { key: "software/firmware/firmware v2.bin", size: 819032832, uploaded: "2026-08-11T10:00:00.000Z" },
  { key: "software/manual v2.pdf", size: 51200, uploaded: "2025-12-31T23:59:00.000Z" },
  { key: "software/readme.txt", size: 120, uploaded: "2026-10-01T08:30:00.000Z" },
  { key: ".r2-explorer/secret.json", size: 10, uploaded: "2026-10-01T08:30:00.000Z" },
];

const mock = createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  // API_BASE may carry a path prefix, so strip it before routing.
  const path = url.pathname.replace(/^\/storage/, "");
  const send = (body, type = "application/json") => {
    res.writeHead(200, { "content-type": type });
    res.end(typeof body === "string" ? body : JSON.stringify(body));
  };
  if (path === "/api/server/config") return send({ version: "1.1.10", config: { readonly: true }, buckets: [{ name: "wuwenzhen" }] });
  const prefix = url.searchParams.get("prefix") ? Buffer.from(url.searchParams.get("prefix"), "base64").toString("utf8") : "";
  if (path === "/api/buckets/wuwenzhen") {
    const inScope = objects.filter((o) => o.key.startsWith(prefix));
    const prefixes = new Set();
    const files = [];
    for (const o of inScope) {
      const rest = o.key.slice(prefix.length);
      const slash = rest.indexOf("/");
      if (slash === -1) files.push(o);
      else prefixes.add(prefix + rest.slice(0, slash + 1));
    }
    return send({ objects: files, truncated: false, delimitedPrefixes: [...prefixes] });
  }
  if (path.startsWith("/api/buckets/wuwenzhen/")) {
    const raw = path.slice("/api/buckets/wuwenzhen/".length);
    let key = "";
    try { key = Buffer.from(decodeURIComponent(raw), "base64").toString("utf8"); } catch {}
    const found = objects.find((o) => o.key === key);
    console.log("mock download:", JSON.stringify(key), found ? "HIT" : "MISS");
    if (!found) { res.writeHead(404, { "content-type": "application/json" }); return res.end("{}"); }
    res.writeHead(200, { "content-type": "application/octet-stream", "content-length": String(found.size) });
    return res.end(Buffer.alloc(found.size, 7));
  }
  res.writeHead(404);
  res.end("{}");
});
await new Promise((r) => mock.listen(8791, "127.0.0.1", r));
console.log("mock storage on 8791");

// ------------------------------------------------------------- worker process
const wrangler = join(ROOT, "node_modules", ".bin", process.platform === "win32" ? "wrangler.cmd" : "wrangler");
const worker = spawn("cmd", ["/c", wrangler, "dev", "--port", "8790", "--ip", "127.0.0.1"], {
  cwd: ROOT, stdio: "ignore", detached: true,
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let healthy = false;
for (let i = 0; i < 60 && !healthy; i++) {
  await sleep(1000);
  try { healthy = (await (await fetch("http://127.0.0.1:8790/healthz")).json()).ok; } catch {}
}
console.log("worker healthy:", healthy);

// --------------------------------------------------------------- cdp session
const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const PORT = 9300 + Math.floor(Math.random() * 600);
const edge = spawn(EDGE, [
  "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
  `--remote-debugging-port=${PORT}`, "--user-data-dir=" + join(TMP, "cdp-" + PORT),
  "--window-size=1200,900", "http://127.0.0.1:8790/",
], { stdio: "ignore" });

let target = null;
for (let i = 0; i < 40 && !target; i++) {
  await sleep(400);
  try {
    target = (await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()).find((t) => t.type === "page" && t.webSocketDebuggerUrl);
  } catch {}
}
if (!target) {
  console.error("???????????CDP??????????????? EDGE ????????");
  edge.kill();
  process.exit(1);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r));
let id = 0;
const pending = new Map();
const consoleErrors = [];
ws.addEventListener("message", (event) => {
  const msg = JSON.parse(event.data);
  if (msg.method === "Runtime.consoleAPICalled" && ["error", "warning"].includes(msg.params.type)) {
    consoleErrors.push(msg.params.args.map((a) => a.value ?? a.description).join(" "));
  }
  if (msg.method === "Runtime.exceptionThrown") consoleErrors.push("EXCEPTION " + (msg.params.exceptionDetails?.exception?.description || ""));
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
});
const send = (method, params) => new Promise((r) => { const n = ++id; pending.set(n, r); ws.send(JSON.stringify({ id: n, method, params })); });
const evaluate = async (expression) => {
  const message = await send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true });
  if (message.result?.exceptionDetails) return { exception: message.result.exceptionDetails.exception?.description || message.result.exceptionDetails.text };
  return message.result?.result?.value;
};
const shot = async (file) => {
  const out = await send("Page.captureScreenshot", { format: "png" });
  const { writeFileSync } = await import("node:fs");
  writeFileSync(file, Buffer.from(out.result.data, "base64"));
};

await send("Runtime.enable");
await send("Page.enable");
await sleep(2600);

const report = {};
report.title = await evaluate("document.title");
report.brand = await evaluate("document.querySelector('.brand-name').textContent");
report.rootRows = await evaluate("[...document.querySelectorAll('.row')].map(r=>r.className+'|'+(r.querySelector('.label')||{}).textContent)");
report.folderLayout = await evaluate(`(()=>{const r=document.querySelector('.row.folder');const c=getComputedStyle(r);const box=r.getBoundingClientRect();return {columns:c.gridTemplateColumns,height:Math.round(box.height),kids:[...r.children].map(k=>{const b=k.getBoundingClientRect();return {cls:k.className,y:Math.round(b.y),h:Math.round(b.height)}})}})()`);
report.imageOk = await evaluate("[...document.images].map(i=>i.naturalWidth>0)");
report.hasR2Brand = await evaluate("/r2[\\s-]?explorer/i.test(document.documentElement.innerHTML)");
await shot(TMP + "/t1-root.png");

// navigate into a folder
await evaluate(`[...document.querySelectorAll('.row.folder')][0].click()`);
await sleep(1500);
report.afterFolderClick = await evaluate(`({url:location.search, crumbs:[...document.querySelectorAll('#crumbs a,#crumbs .here')].map(e=>e.textContent), rows:[...document.querySelectorAll('.row .label')].map(e=>e.textContent)})`);
await shot(TMP + "/t2-folder.png");

// nested folder
await evaluate(`(()=>{const f=[...document.querySelectorAll('.row.folder')][0]; if(f) f.click();})()`);
await sleep(1500);
report.nested = await evaluate(`({url:location.search, rows:[...document.querySelectorAll('.row .label')].map(e=>e.textContent)})`);

// search filter
await evaluate(`(()=>{const i=document.getElementById('search'); i.value='app'; i.dispatchEvent(new Event('input'))})()`);
await sleep(300);
report.searchRows = await evaluate(`[...document.querySelectorAll('.row .label')].map(e=>e.textContent)`);
await evaluate(`document.getElementById('search-clear').click()`);
await sleep(200);

// download link shape + real byte transfer (still inside the nested folder)
report.fileRowLayout = await evaluate(`(()=>{const r=document.querySelector('.row.file');const c=getComputedStyle(r);return {columns:c.gridTemplateColumns,height:Math.round(r.getBoundingClientRect().height),kids:[...r.children].map(k=>{const b=k.getBoundingClientRect();return {cls:k.className,y:Math.round(b.y),x:Math.round(b.x)}})}})()`);
report.downloadHref = await evaluate(`document.querySelector('.row.file .get').getAttribute('href')`);
report.download = await evaluate(`(async()=>{const href=document.querySelector('.row.file .get').getAttribute('href');const r=await fetch(href,{method:'HEAD'});return {href,status:r.status,len:r.headers.get('content-length'),type:r.headers.get('content-type'),disp:r.headers.get('content-disposition')}})()`);
report.downloadError = await evaluate(`(async()=>{const href=document.querySelector('.row.file .get').getAttribute('href');const r=await fetch(href);return {status:r.status,body:(await r.text()).slice(0,300)}})()`);
report.downloadBody = await evaluate(`(async()=>{const href=document.querySelector('.row.file .get').getAttribute('href');const r=await fetch(href);const b=await r.arrayBuffer();return {status:r.status,bytes:b.byteLength}})()`);

// breadcrumb back to root
await evaluate(`[...document.querySelectorAll('#crumbs a')][0].click()`);
await sleep(1500);
report.backToRoot = await evaluate(`({url:location.search, rows:[...document.querySelectorAll('.row .label')].map(e=>e.textContent)})`);

// hidden internal prefix must never show up
report.hiddenLeaked = await evaluate(`/r2-explorer/.test(document.body.innerHTML)`);

// a non-ASCII key (space + CJK) must survive the round trip too
report.unicodeDownload = await evaluate(`(async()=>{
  const row=[...document.querySelectorAll('.row.file')].find(r=>r.querySelector('.label').textContent.includes('manual v2'));
  const href=row.querySelector('.get').getAttribute('href');
  const res=await fetch(href,{method:'HEAD'});
  return {href,status:res.status,len:res.headers.get('content-length'),disp:res.headers.get('content-disposition')};
})()`);

// folder download must not be offered as a file
report.emptyState = await evaluate(`(()=>{const i=document.getElementById('search');i.value='zzzz';i.dispatchEvent(new Event('input'));const hidden=document.getElementById('empty').hidden;return {emptyHidden:hidden}})()`);

// dark theme
await evaluate(`document.getElementById('theme-btn').click()`);
await sleep(400);
report.theme = await evaluate(`({attr:document.documentElement.dataset.theme, bg:getComputedStyle(document.body).backgroundColor, stored:localStorage.getItem('wenzhen-theme')})`);
await shot(TMP + "/t3-dark.png");
await evaluate(`document.getElementById('theme-btn').click()`);

// mobile viewport
await send("Emulation.setDeviceMetricsOverride", { width: 390, height: 844, deviceScaleFactor: 2, mobile: true });
await sleep(600);
report.mobile = await evaluate(`(()=>{const r=document.querySelector('.row.file');const c=getComputedStyle(r);return {columns:c.gridTemplateColumns, height:Math.round(r.getBoundingClientRect().height), nameVisible:!!document.querySelector('.row.file .label').offsetWidth, timeDisplay:getComputedStyle(document.querySelector('.row.file .time')).display}})()`);
await shot(TMP + "/t4-mobile.png");
await send("Emulation.clearDeviceMetricsOverride");

report.consoleErrors = consoleErrors;
console.log(JSON.stringify(report, null, 1));

ws.close();
edge.kill();
try { process.kill(-worker.pid); } catch { worker.kill(); }
mock.close();
process.exit(0);