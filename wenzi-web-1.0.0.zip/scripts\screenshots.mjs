// Captures desktop and mobile screenshots from a running instance.
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";

import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// Paths are derived from this file so the scripts work from any clone location.
const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const TMP = join(ROOT, ".tmp");
mkdirSync(TMP, { recursive: true });

const base = process.argv[2] || "http://127.0.0.1:8793";
const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const PORT = 9300 + Math.floor(Math.random() * 600);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const edge = spawn(EDGE, ["--headless=new", "--disable-gpu", "--no-first-run", "--hide-scrollbars", `--remote-debugging-port=${PORT}`, "--user-data-dir=" + join(TMP, "cdp-" + PORT), "--window-size=1240,820", base + "/"], { stdio: "ignore" });

let target = null;
for (let i = 0; i < 40 && !target; i++) {
  await sleep(400);
  try { target = (await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()).find((t) => t.type === "page" && t.webSocketDebuggerUrl); } catch {}
}
if (!target) {
  console.error("???????????CDP??????????????? EDGE ????????");
  edge.kill();
  process.exit(1);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r));
let id = 0;
const pending = new Map();
ws.addEventListener("message", (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } });
const send = (method, params) => new Promise((r) => { const n = ++id; pending.set(n, r); ws.send(JSON.stringify({ id: n, method, params })); });
const evaluate = async (expression) => (await send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true })).result?.result?.value;
const shot = async (file) => { const out = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false }); writeFileSync(file, Buffer.from(out.result.data, "base64")); console.log("shot:", file); };

for (let i = 0; i < 30; i++) { await sleep(1000); if (await evaluate("!!document.querySelector('.row')")) break; }

await shot(TMP + "/final-desktop.png");
await evaluate("document.getElementById('theme-btn').click()");
await sleep(600);
await shot(TMP + "/final-dark.png");
await evaluate("document.getElementById('theme-btn').click()");
await sleep(400);

await send("Emulation.setDeviceMetricsOverride", { width: 390, height: 844, deviceScaleFactor: 2, mobile: true });
await sleep(800);
console.log("mobile layout:", JSON.stringify(await evaluate(`(()=>{const r=document.querySelector('.row.file');const c=getComputedStyle(r);return {columns:c.gridTemplateColumns,rowHeight:Math.round(r.getBoundingClientRect().height),time:getComputedStyle(r.querySelector('.time')).display,sub:getComputedStyle(r.querySelector('.sub')).display,copy:getComputedStyle(r.querySelector('.copy')).display,actionsX:Math.round(r.querySelector('.actions').getBoundingClientRect().x),pageWidth:document.documentElement.scrollWidth,viewport:window.innerWidth}})()`)));
await shot(TMP + "/final-mobile.png");
ws.close();
edge.kill();
process.exit(0);