// End-to-end check of a running instance: renders the page in a browser,
// then exercises the download endpoints it produced.
import { spawn } from "node:child_process";

import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// Paths are derived from this file so the scripts work from any clone location.
const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const TMP = join(ROOT, ".tmp");
mkdirSync(TMP, { recursive: true });

const base = process.argv[2] || "http://127.0.0.1:8793";
const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const PORT = 9300 + Math.floor(Math.random() * 600);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const edge = spawn(EDGE, ["--headless=new", "--disable-gpu", "--no-first-run", `--remote-debugging-port=${PORT}`, "--user-data-dir=" + join(TMP, "cdp-" + PORT), "--window-size=1200,900", base + "/"], { stdio: "ignore" });

let target = null;
for (let i = 0; i < 40 && !target; i++) {
  await sleep(400);
  try { target = (await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()).find((t) => t.type === "page" && t.webSocketDebuggerUrl); } catch {}
}
if (!target) {
  console.error("???????????CDP??????????????? EDGE ????????");
  edge.kill();
  process.exit(1);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r));
let id = 0;
const pending = new Map();
ws.addEventListener("message", (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } });
const send = (method, params) => new Promise((r) => { const n = ++id; pending.set(n, r); ws.send(JSON.stringify({ id: n, method, params })); });
const evaluate = async (expression) => (await send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true })).result?.result?.value;
for (let i = 0; i < 30; i++) { await sleep(1000); if (await evaluate("!!document.querySelector(\".row\")")) break; }

const rowInfo = await evaluate(`[...document.querySelectorAll('.row')].map(r=>({kind:r.className,href:(r.querySelector('.get')||{}).getAttribute? r.querySelector('.get').getAttribute('href'):null,name:r.querySelector('.label').textContent}))`);
console.log("rows:", JSON.stringify(rowInfo, null, 1));
console.log("brand:", await evaluate("document.querySelector('.brand-name').textContent"), "| title:", await evaluate("document.title"));

for (const row of rowInfo.filter((r) => r.href)) {
  const url = base + row.href;
  const head = await fetch(url, { method: "HEAD" });
  console.log("HEAD", row.name, "->", head.status, "len", head.headers.get("content-length"), "|", head.headers.get("content-disposition"));
}
const first = rowInfo.find((r) => r.href);
if (first) {
  const url = base + first.href;
  const get = await fetch(url);
  const buf = await get.arrayBuffer();
  console.log("GET ", first.name, "->", get.status, "bytes", buf.byteLength);
  const range = await fetch(url, { headers: { range: "bytes=0-99" } });
  console.log("RANGE", first.name, "->", range.status, "bytes", (await range.arrayBuffer()).byteLength, range.headers.get("content-range"));
}
ws.close();
edge.kill();
process.exit(0);