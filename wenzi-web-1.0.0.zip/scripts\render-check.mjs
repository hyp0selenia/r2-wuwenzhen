import { renderPage } from "../src/ui.js";
const html = renderPage({
  title: "蚊子网",
  initial: {
    path: "",
    files: [{ key: "a.apk", name: "a.apk", size: 2048, uploaded: "2026-09-01T10:00:00.000Z" }],
    folders: [{ prefix: "sub/", name: "sub" }],
    cursor: null,
  },
});
for (const phrase of ["文件下载中心", "仅供文件浏览与下载", "位置：", "R2-Explorer", "r2-explorer"]) {
  console.log(phrase + ":", html.includes(phrase) ? "STILL PRESENT" : "removed");
}
const pick = (re) => (html.match(re) || [""])[0].replace(/\s+/g, " ").trim();
console.log("footer:", pick(/<footer>[\s\S]*?<\/footer>/));
console.log("brand:", pick(/<a class="brand"[\s\S]*?<\/a>/));
console.log("meta:", pick(/<div class="meta">[\s\S]*?<\/div>/));