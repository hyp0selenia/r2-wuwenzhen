// Full verification of a live deployment, driven through a real browser.
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";

import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// Paths are derived from this file so the scripts work from any clone location.
const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const TMP = join(ROOT, ".tmp");
mkdirSync(TMP, { recursive: true });

const base = process.argv[2] || "https://wenzhen.ccwu.cc";
const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const PORT = 9300 + Math.floor(Math.random() * 600);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const edge = spawn(EDGE, ["--headless=new", "--disable-gpu", "--no-first-run", "--hide-scrollbars", `--remote-debugging-port=${PORT}`, "--user-data-dir=" + join(TMP, "cdp-" + PORT), "--window-size=1240,860", base + "/"], { stdio: "ignore" });

let target = null;
for (let i = 0; i < 40 && !target; i++) { await sleep(400); try { target = (await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()).find((t) => t.type === "page" && t.webSocketDebuggerUrl); } catch {} }
if (!target) {
  console.error("???????????CDP??????????????? EDGE ????????");
  edge.kill();
  process.exit(1);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r));
let id = 0; const pending = new Map(); const problems = [];
ws.addEventListener("message", (e) => {
  const m = JSON.parse(e.data);
  if (m.method === "Runtime.exceptionThrown") problems.push("EXCEPTION " + (m.params.exceptionDetails?.exception?.description || ""));
  if (m.method === "Log.entryAdded" && ["error", "warning"].includes(m.params.entry.level)) problems.push(m.params.entry.level + ": " + m.params.entry.text);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
});
const send = (method, params) => new Promise((r) => { const n = ++id; pending.set(n, r); ws.send(JSON.stringify({ id: n, method, params })); });
const evaluate = async (expression) => (await send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true })).result?.result?.value;
const shot = async (file) => { const out = await send("Page.captureScreenshot", { format: "png" }); writeFileSync(file, Buffer.from(out.result.data, "base64")); };

await send("Runtime.enable"); await send("Log.enable"); await send("Page.enable");
for (let i = 0; i < 40; i++) { await sleep(1000); if (await evaluate("!!document.querySelector('.row')")) break; }

const report = {};
report.url = await evaluate("location.href");
report.title = await evaluate("document.title");
report.brand = await evaluate("document.querySelector('.brand-name').textContent");
report.favicon = await evaluate(`(()=>{const l=[...document.querySelectorAll('link[rel*=icon]')].map(e=>e.getAttribute('href'));return l})()`);
report.iconsLoaded = await evaluate(`[...document.images].map(i=>({src:i.getAttribute('src'),ok:i.naturalWidth>0}))`);
report.brandLeak = await evaluate(`/r2[\\s-]?explorer/i.test(document.documentElement.innerHTML)`);
report.rows = await evaluate(`[...document.querySelectorAll('.row')].map(r=>({name:r.querySelector('.label').textContent,size:(r.querySelector('.size')||{}).textContent,time:(r.querySelector('.time')||{}).textContent||'',href:(r.querySelector('.get')||{}).getAttribute?r.querySelector('.get').getAttribute('href'):null}))`);
report.moreHidden = await evaluate("document.getElementById('more').hidden");
await shot(TMP + "/live-desktop.png");

// Real in-page download of the smallest file, exactly like clicking 下载.
report.download = await evaluate(`(async()=>{
  const row=[...document.querySelectorAll('.row.file')].sort((a,b)=>0)[0];
  const href=row.querySelector('.get').getAttribute('href');
  const res=await fetch(href);
  const buf=await res.arrayBuffer();
  return {name:row.querySelector('.label').textContent,status:res.status,bytes:buf.byteLength,type:res.headers.get('content-type'),disp:res.headers.get('content-disposition')};
})()`);

// Searching + theme still behave against production data.
await evaluate(`(()=>{const i=document.getElementById('search');i.value='JMComic';i.dispatchEvent(new Event('input'))})()`);
await sleep(400);
report.searchFiltered = await evaluate(`[...document.querySelectorAll('.row .label')].map(e=>e.textContent)`);
await evaluate(`document.getElementById('search-clear').click()`);
await sleep(300);
await evaluate(`document.getElementById('theme-btn').click()`);
await sleep(500);
report.darkBg = await evaluate("getComputedStyle(document.body).backgroundColor");
await shot(TMP + "/live-dark.png");
await evaluate(`document.getElementById('theme-btn').click()`);
await sleep(400);

// Mobile rendering against production.
await send("Emulation.setDeviceMetricsOverride", { width: 390, height: 844, deviceScaleFactor: 2, mobile: true });
await sleep(800);
report.mobile = await evaluate(`(()=>{const r=document.querySelector('.row.file');return {columns:getComputedStyle(r).gridTemplateColumns,overflow:document.documentElement.scrollWidth>window.innerWidth,viewport:window.innerWidth}})()`);
await shot(TMP + "/live-mobile.png");

report.problems = problems;
console.log(JSON.stringify(report, null, 1));
ws.close(); edge.kill(); process.exit(0);