// Generates the 蚊子网 icon set from the source mascot artwork (scripts/source-favicon.jpg).
// The source is a JPEG on flat white paper, so every mark is first re-keyed to real
// transparency (white -> alpha) and only then resized/centred on the target canvas.
import { mkdirSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const require = createRequire(import.meta.url);

// sharp is an optional dev dependency: `npm i -D sharp` resolves it normally,
// and SHARP_PATH lets you point at an install that lives elsewhere.
let sharp;
try {
  sharp = require(process.env.SHARP_PATH || "sharp");
} catch {
  console.error(
    [
      "找不到 sharp，无法生成图标。",
      "",
      "  npm i -D sharp          # 常规做法",
      "  SHARP_PATH=/path/to/sharp node scripts/gen-icons.mjs   # 或用现成的安装",
      "",
      "已有的 public/ 图标可以直接使用，不重新生成也没关系。",
    ].join("\n"),
  );
  process.exit(1);
}

const here = dirname(fileURLToPath(import.meta.url));
const out = join(here, "..", "public");
mkdirSync(join(out, "icons"), { recursive: true });

const { data, info } = await sharp(join(here, "source-favicon.jpg"))
  .ensureAlpha()
  .raw()
  .toBuffer({ resolveWithObject: true });

// White -> alpha key: alpha = 1 - min(r,g,b)/255, colour un-premultiplied so
// yellow stays saturated and the dark outline stays crisp.
const rgba = Buffer.alloc(info.width * info.height * 4);
for (let i = 0; i < data.length; i += 4) {
  const r = data[i];
  const g = data[i + 1];
  const b = data[i + 2];
  const white = Math.min(r, g, b) / 255;
  const a = 1 - white;
  if (a <= 0.004) continue;
  rgba[i] = Math.min(255, Math.round(Math.max(0, r - 255 * white) / a));
  rgba[i + 1] = Math.min(255, Math.round(Math.max(0, g - 255 * white) / a));
  rgba[i + 2] = Math.min(255, Math.round(Math.max(0, b - 255 * white) / a));
  rgba[i + 3] = Math.round(a * 255);
}

const trimmed = await sharp(rgba, { raw: { width: info.width, height: info.height, channels: 4 } })
  .trim({ threshold: 2 })
  .png()
  .toBuffer({ resolveWithObject: true });
console.log("keyed artwork:", trimmed.info.width + "x" + trimmed.info.height);

const art = (size) =>
  sharp(trimmed.data)
    .resize(size, size, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toBuffer();

const square = async (size, pad) => {
  const inner = Math.max(1, Math.round(size * (1 - pad * 2)));
  return sharp({
    create: { width: size, height: size, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } },
  })
    .composite([{ input: await art(inner), gravity: "center" }])
    .png({ compressionLevel: 9 })
    .toBuffer();
};

const png16 = await square(16, 0.03);
const png32 = await square(32, 0.03);
const png48 = await square(48, 0.04);
writeFileSync(join(out, "icons", "favicon-16x16.png"), png16);
writeFileSync(join(out, "icons", "favicon-32x32.png"), png32);
writeFileSync(join(out, "icons", "favicon-96x96.png"), await square(96, 0.04));
writeFileSync(join(out, "icons", "favicon-128x128.png"), await square(128, 0.04));
writeFileSync(join(out, "icons", "logo-mark.png"), await square(256, 0.02));

// Rounded cream app-icon look for the PWA and touch icons.
const roundedMask = (size, radius) =>
  Buffer.from(
    `<svg width="${size}" height="${size}"><rect x="0" y="0" width="${size}" height="${size}" rx="${radius}" ry="${radius}" fill="#fff"/></svg>`,
  );

const onCream = async (size, radius, pad) => {
  const bg = await sharp({
    create: { width: size, height: size, channels: 4, background: { r: 255, g: 249, b: 224, alpha: 1 } },
  })
    .composite([{ input: roundedMask(size, radius), blend: "dest-in" }])
    .png()
    .toBuffer();
  return sharp(bg)
    .composite([{ input: await art(Math.round(size * (1 - pad * 2))), gravity: "center" }])
    .png({ compressionLevel: 9 })
    .toBuffer();
};

writeFileSync(join(out, "icons", "logo.png"), await onCream(192, 44, 0.12));
writeFileSync(join(out, "icons", "apple-touch-icon.png"), await onCream(180, 40, 0.12));
writeFileSync(join(out, "icons", "icon-512.png"), await onCream(512, 116, 0.12));

// Multi-resolution favicon.ico (16 + 32 + 48) built from the PNG payloads above.
const images = [png16, png32, png48];
const dims = [16, 32, 48];
const header = Buffer.alloc(6);
header.writeUInt16LE(0, 0);
header.writeUInt16LE(1, 2);
header.writeUInt16LE(images.length, 4);
let offset = 6 + images.length * 16;
const entries = images.map((img, i) => {
  const e = Buffer.alloc(16);
  e.writeUInt8(dims[i], 0);
  e.writeUInt8(dims[i], 1);
  e.writeUInt8(0, 2);
  e.writeUInt8(0, 3);
  e.writeUInt16LE(1, 4);
  e.writeUInt16LE(32, 6);
  e.writeUInt32LE(img.length, 8);
  e.writeUInt32LE(offset, 12);
  offset += img.length;
  return e;
});
writeFileSync(join(out, "favicon.ico"), Buffer.concat([header, ...entries, ...images]));
console.log("icon set written to public/");