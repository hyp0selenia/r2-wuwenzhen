/**
 * 蚊子网 (wenzhen.ccwu.cc) - public read-only file browser.
 *
 * The page only exposes two capabilities: browsing the folder tree and
 * downloading files. Anything else the storage backend supports (upload,
 * delete, rename, metadata, share links, email) is intentionally unreachable
 * from this Worker, and the upstream API is run in readonly mode.
 *
 * Upstream traffic prefers a Cloudflare service binding to the storage Worker
 * so the file list never has to leave the edge; it falls back to public HTTPS
 * so the project also works without any extra dashboard configuration.
 */
import { renderPage } from "./ui.js";

const DEFAULTS = {
	apiBase: "https://api.wenzhen.ccwu.cc",
	bucket: "wuwenzhen",
	hiddenPrefix: ".r2-explorer/",
	title: "蚊子网",
	// Name of the service binding declared in wrangler.toml ([[services]]).
	service: "API_SERVICE",
};

// Bot-protection friendly headers. Cloudflare's managed rules reject requests
// that look like bare scripts, so upstream calls carry a normal browser shape.
const UA =
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36";

const envValue = (env, key, fallback) => {
	const v = env?.[key];
	return typeof v === "string" && v.length > 0 ? v : fallback;
};

const settings = (env) => ({
	apiBase: envValue(env, "API_BASE", DEFAULTS.apiBase).replace(/\/+$/, ""),
	bucket: envValue(env, "BUCKET_NAME", DEFAULTS.bucket),
	hiddenPrefix: envValue(env, "HIDDEN_PREFIX", DEFAULTS.hiddenPrefix),
	title: envValue(env, "SITE_TITLE", DEFAULTS.title),
	service: envValue(env, "API_SERVICE", DEFAULTS.service),
});

const upstreamHeaders = (request) => {
	const headers = new Headers({
		"user-agent": UA,
		accept: "application/json, text/plain, */*",
		"accept-language": request?.headers.get("accept-language") || "zh-CN,zh;q=0.9,en;q=0.8",
	});
	const referer = request?.headers.get("referer");
	if (referer) headers.set("referer", referer);
	return headers;
};

const encodeBase64 = (value) =>
	btoa(String.fromCharCode(...new TextEncoder().encode(value)));

const decodeBase64 = (value) =>
	new TextDecoder().decode(Uint8Array.from(atob(value), (c) => c.charCodeAt(0)));

const toBase64Url = (value) => encodeBase64(value).replace(/\+/g, "-").replace(/\//g, "_");

const fromBase64Url = (value) => {
	const padded = value.replace(/-/g, "+").replace(/_/g, "/");
	return decodeBase64(padded + "=".repeat((4 - (padded.length % 4)) % 4));
};

/** Talks to the storage Worker through a service binding, else over HTTPS. */
async function upstream(env, request, path, init = {}) {
	const cfg = settings(env);
	const headers = init.headers || upstreamHeaders(request);
	const method = init.method || "GET";
	const binding = cfg.service ? env?.[cfg.service] : undefined;

	if (typeof binding?.fetch === "function") {
		try {
			const viaBinding = await binding.fetch(
				new Request(`https://${cfg.service.toLowerCase()}.internal${path}`, { method, headers }),
			);
			// The storage Worker answers /api/* with JSON. For static assets it
			// serves its own SPA; if the asset is missing it 404s, and that 404 is
			// still the correct answer to pass through.
			const type = viaBinding.headers.get("content-type") || "";
			if (!/text\/html/i.test(type)) return viaBinding;
		} catch {
			// Fall through to the public HTTPS transport below.
		}
	}

	// Public HTTPS is only a fallback: with a working service binding the
	// upstream domain (and its admin UI) does not need to be reachable at all.
	if (!cfg.apiBase) throw new Error("上游不可用：service binding 未生效，且未配置 API_BASE");
	const url = path.startsWith("http") ? path : cfg.apiBase + path;
	try {
		return await fetch(url, { ...init, method, headers });
	} catch (error) {
		throw new Error(`无法连接上游 ${new URL(cfg.apiBase).host}：${error.message}`);
	}
}

/**
 * Resolves the bucket name. The configured value wins; otherwise the storage
 * API is asked which bucket it serves, so this project keeps working after a
 * bucket rename without shipping a new deployment.
 */
async function bucketName(env, request) {
	const cfg = settings(env);
	if (cfg.bucket) return cfg.bucket;
	const res = await upstream(env, request, "/api/server/config");
	if (!res.ok) throw new Error(`storage config unavailable (${res.status})`);
	const body = await res.json();
	const name = body?.buckets?.[0]?.name;
	if (!name) throw new Error("storage reports no buckets");
	return name;
}

const isHidden = (key, cfg) => cfg.hiddenPrefix !== "" && key.startsWith(cfg.hiddenPrefix);

/** Reads one folder level: files, child folders and the pagination cursor. */
async function listFolder(env, request, cfg, path, cursor) {
	const bucket = await bucketName(env, request);
	const query = new URLSearchParams({ delimiter: "/" });
	if (path) query.set("prefix", encodeBase64(path));
	if (cursor) query.set("cursor", cursor);

	const res = await upstream(
		env,
		request,
		`/api/buckets/${encodeURIComponent(bucket)}?${query.toString()}`,
	);
	if (!res.ok) throw new Error(`无法读取文件列表（${res.status}）`);

	const body = await res.json();
	const files = (body.objects || [])
		.filter((o) => !isHidden(o.key, cfg))
		.map((o) => ({
			key: o.key,
			name: o.key.slice(path.length),
			size: o.size,
			uploaded: o.uploaded,
		}))
		.filter((o) => o.name !== "" && !o.name.endsWith("/"));

	const folders = (body.delimitedPrefixes || [])
		.filter((p) => !isHidden(p, cfg))
		.map((p) => ({ prefix: p, name: p.slice(path.length).replace(/\/$/, "") }))
		.filter((f) => f.name !== "");

	return {
		files,
		folders,
		cursor: body.truncated ? body.cursor || null : null,
	};
}

const html = (body, status = 200, extraHeaders = {}) =>
	new Response(body, {
		status,
		headers: {
			"content-type": "text/html; charset=utf-8",
			"cache-control": "no-store",
			"x-content-type-options": "nosniff",
			"referrer-policy": "no-referrer",
			...extraHeaders,
		},
	});

function errorPage(message) {
	return html(
		`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>蚊子网</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#fdfaf1;color:#2c2618;font:16px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}
.box{max-width:32rem;padding:2.5rem;background:#fff;border:1px solid #f0e7cd;border-radius:20px;box-shadow:0 18px 40px -28px rgba(44,38,24,.35);text-align:center}
h1{margin:.2rem 0 .6rem;font-size:1.35rem}p{margin:.4rem 0;color:#6d6350}a{color:#b07d00}</style></head>
<body><div class="box"><div style="font-size:2.6rem">🦟</div><h1>暂时无法读取文件列表</h1><p>${String(message).replace(/[<>&]/g, "")}</p><p><a href="/">重新加载</a></p></div></body></html>`,
		502,
	);
}

/** Streams one object from the storage API, preserving range requests. */
async function download(env, request, key) {
	if (!key) return new Response("缺少文件名", { status: 400 });
	const bucket = await bucketName(env, request);
	const headers = upstreamHeaders(request);
	const range = request.headers.get("range");
	if (range) headers.set("range", range);
	if (request.headers.get("if-none-match")) headers.set("if-none-match", request.headers.get("if-none-match"));

	const res = await upstream(
		env,
		request,
		`/api/buckets/${encodeURIComponent(bucket)}/${encodeURIComponent(encodeBase64(key))}`,
		{ method: "GET", headers },
	);

	if (!res.ok && res.status !== 206) {
		return new Response(`无法下载该文件（${res.status}）`, {
			status: res.status === 404 ? 404 : 502,
			headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" },
		});
	}

	const name = key.split("/").pop() || "download";
	const ascii = name.replace(/[^\x20-\x7E]/g, "_").replace(/["\\]/g, "'");
	const out = new Headers({
		"content-type": res.headers.get("content-type") || "application/octet-stream",
		"content-disposition": `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(name)}`,
		"cache-control": "private, max-age=0, must-revalidate",
		"x-content-type-options": "nosniff",
	});
	for (const header of ["content-length", "content-range", "accept-ranges", "etag", "last-modified"]) {
		const value = res.headers.get(header);
		if (value) out.set(header, value);
	}
	return new Response(res.body, { status: res.status, headers: out });
}

export default {
	async fetch(request, env) {
		const cfg = settings(env);
		const url = new URL(request.url);
		const path = url.pathname;

		if (request.method !== "GET" && request.method !== "HEAD") {
			return new Response("只支持查看与下载", { status: 405, headers: { allow: "GET, HEAD" } });
		}

		// /dl/<base64url key> keeps non-ASCII and nested file names link-safe.
		if (path.startsWith("/dl/")) {
			try {
				return await download(env, request, fromBase64Url(decodeURIComponent(path.slice(4))));
			} catch (error) {
				return new Response(`下载失败：${error.message}`, {
					status: 502,
					headers: { "content-type": "text/plain; charset=utf-8" },
				});
			}
		}

		if (path === "/api/list") {
			try {
				const folder = (url.searchParams.get("path") || "").replace(/^\/+/, "");
				const safe = folder.endsWith("/") || folder === "" ? folder : `${folder}/`;
				const result = await listFolder(env, request, cfg, safe, url.searchParams.get("cursor"));
				return Response.json(result, { headers: { "cache-control": "no-store" } });
			} catch (error) {
				return Response.json({ error: error.message }, { status: 502 });
			}
		}

		if (path === "/" || path === "/index.html") {
			let initial = { path: "", files: [], folders: [], cursor: null };
			let failure = null;
			try {
				initial = { path: "", ...(await listFolder(env, request, cfg, "", null)) };
			} catch (error) {
				failure = error.message;
			}
			if (failure) return errorPage(failure);
			return html(renderPage({ title: cfg.title, initial }));
		}

		if (path === "/healthz") {
			try {
				const bucket = await bucketName(env, request);
				const probe = await listFolder(env, request, settings(env), "", null);
				return Response.json({ ok: true, bucket, files: probe.files.length, folders: probe.folders.length });
			} catch (error) {
				return Response.json({ ok: false, error: error.message }, { status: 502 });
			}
		}

		// Everything else is a static asset (icons, favicon, web manifest).
		if (env?.ASSETS) {
			const asset = await env.ASSETS.fetch(request);
			if (asset.status !== 404) return asset;
		}

		return new Response("页面不存在", { status: 404, headers: { "content-type": "text/plain; charset=utf-8" } });
	},
};